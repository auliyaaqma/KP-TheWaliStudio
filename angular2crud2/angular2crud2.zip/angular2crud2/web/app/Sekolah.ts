export class Sekolah{
    id: number;
    nama: string;
    kelas: string;
    jurusan: string;
}