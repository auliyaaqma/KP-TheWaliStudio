"use strict";
var Sekolah = (function () {
    function Sekolah() {
    }
    return Sekolah;
}());
exports.Sekolah = Sekolah;
//# sourceMappingURL=Sekolah.js.map