"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var common_1 = require('@angular/common');
var router_1 = require('@angular/router');
var sekolah_service_1 = require('../service/sekolah.service');
var FormComponent = (function () {
    function FormComponent(activeRoute, location, sekolahService) {
        this.activeRoute = activeRoute;
        this.location = location;
        this.sekolahService = sekolahService;
        this.title = '';
    }
    FormComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.activeRoute.params.forEach(function (param) {
            var act = param['act'];
            if (act == 'add') {
                _this.title = 'Add Student';
                _this.action = 'add';
            }
            else {
                var id = param['id'];
                _this.selectedId = id;
                _this.title = 'Edit Student';
                _this.action = 'edit';
            }
        });
        if (this.action == 'edit') {
            this.getData(this.selectedId);
        }
    };
    FormComponent.prototype.getData = function (id) {
        var _this = this;
        this.sekolahService.getStudent(id)
            .subscribe(function (students) { return _this.student = students; }, function (error) { return console.log(error); });
    };
    FormComponent.prototype.goBack = function () {
        this.location.back();
    };
    FormComponent.prototype.addStudent = function (nama, kelas, jurusan) {
        var _this = this;
        nama = nama.trim();
        kelas = kelas.trim();
        jurusan = jurusan.trim();
        if (!nama || !kelas || !jurusan) {
            this.errorMsg = 'Ada field yang belum terisi!';
            return;
        }
        this.sekolahService.storeData(nama, kelas, jurusan)
            .subscribe(function (res) {
            _this.errorMsg = '';
            if (JSON.parse(res).success == 'success') {
                _this.infoMsg = 'Tambah data murid berhasil!';
            }
        });
    };
    FormComponent.prototype.editStudent = function () {
        var _this = this;
        var nama = this.student.nama;
        var kelas = this.student.kelas;
        var jurusan = this.student.jurusan;
        var id = this.student.id;
        if (!nama || !kelas || !jurusan) {
            this.errorMsg = 'Ada field yang belum terisi!';
            return;
        }
        this.sekolahService.updateData(id, nama, kelas, jurusan)
            .subscribe(function (res) {
            _this.errorMsg = '';
            if (JSON.parse(res).success == 'success') {
                _this.infoMsg = 'Update data murid berhasil!';
            }
        });
    };
    FormComponent = __decorate([
        core_1.Component({
            selector: 'form-component',
            templateUrl: 'app/view/form.component.html'
        }), 
        __metadata('design:paramtypes', [router_1.ActivatedRoute, common_1.Location, sekolah_service_1.SekolahService])
    ], FormComponent);
    return FormComponent;
}());
exports.FormComponent = FormComponent;
//# sourceMappingURL=form.component.js.map