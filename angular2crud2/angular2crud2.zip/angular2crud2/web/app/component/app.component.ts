import { Component } from '@angular/core';

@Component({
	selector: 'app',
	templateUrl: 'app/view/layout/app.component.html'
})

export class AppComponent { }